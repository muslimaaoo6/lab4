from abc import ABC, abstractmethod

class PaymentMethod(ABC):
    @abstractmethod
    def fee(self, amount: int) -> int:
        pass

    @abstractmethod
    def is_refundable(self) -> bool:
        pass

class Card(PaymentMethod):
    def fee(self, amount: int) -> int:
        return amount * 15 // 1000

    def is_refundable(self) -> bool:
        return True

class Click(PaymentMethod):
    def fee(self, amount: int) -> int:
        return amount * 10 // 1000

    def is_refundable(self) -> bool:
        return True

class Payme(PaymentMethod):
    def fee(self, amount: int) -> int:
        return amount * 10 // 1000

    def is_refundable(self) -> bool:
        return True

class Cash(PaymentMethod):
    def fee(self, amount: int) -> int:
        return 0

    def is_refundable(self) -> bool:
        return False

class BankTransfer(PaymentMethod):
    def fee(self, amount: int) -> int:
        return 5000

    def is_refundable(self) -> bool:
        return True

class Checkout:
    def pay(self, method: PaymentMethod, amount: int):
        fee = method.fee(amount)
        return {"charged": amount + fee, "refundable": method.is_refundable()}

def test_checkout_card():
    assert Checkout().pay(Card(), 1000) == {"charged": 1015, "refundable": True}

def test_checkout_bank_transfer():
    assert Checkout().pay(BankTransfer(), 10000) == {"charged": 15000, "refundable": True}