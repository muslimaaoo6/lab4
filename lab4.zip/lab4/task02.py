from abc import ABC, abstractmethod

class Notifier(ABC):
    max_length: int

    @abstractmethod
    def send(self, recipient: str, text: str):
        pass

    def notify(self, recipient: str, text: str):
        self.send(recipient, text[: self.max_length])

class TelegramNotifier(Notifier):
    max_length = 4096

    def send(self, recipient: str, text: str):
        print(f"telegram -> {recipient}: {text}")

class SmsNotifier(Notifier):
    max_length = 160

    def send(self, recipient: str, text: str):
        print(f"sms -> {recipient}: {text}")

# Test qismi: matn uzunligi rostan ham 160 ta belgidan oshmasligini tekshiradi
def test_sms_notifier_cuts_text():
    class DummySmsNotifier(SmsNotifier):
        def send(self, recipient, text):
            self.sent_text = text

    notifier = DummySmsNotifier()
    notifier.notify("@user", "A" * 200)  # 200 ta "A" harfini beramiz
    assert len(notifier.sent_text) == 160  # Lekin u faqat 160 tasini qabul qilishi kerak