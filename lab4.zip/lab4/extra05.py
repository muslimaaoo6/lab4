# E5.4: from_dict nima uchun @classmethod bo'lishi kerak? 
# Agar u staticmethod bo'lsa, OrderPlaced.from_dict() ham, uning bolasining from_dict() ham doim o'sha bitta OrderPlaced obyektini qaytaraveradi. 
# @classmethod esa `cls` parametrini oladi, ya'ni agar voris chaqirsa unga o'zining tipi (class) boradi va to'g'ri obyekt yaratiladi.

class OrderEvent:
    def to_dict(self): pass
    
    @classmethod
    def from_dict(cls, data): pass

class OrderPlaced(OrderEvent):
    def __init__(self, order_id, total_tiyin, currency, promo_code=None):
        self.order_id = order_id
        self.total_tiyin = total_tiyin
        self.currency = currency
        self.promo_code = promo_code

    def to_dict(self):
        return {
            "type": "OrderPlaced",
            "version": 2, # E5.3: v2 ga o'tdik
            "order_id": self.order_id,
            "total_tiyin": self.total_tiyin,
            "currency": self.currency,
            "promo_code": self.promo_code
        }

    @classmethod
    def from_dict(cls, data):
        # Eski (v1) xabarlarda promo_code bo'lmasa, uni None qilib qo'yadi. (E5.3)
        return cls(
            order_id=data["order_id"],
            total_tiyin=data["total_tiyin"],
            currency=data["currency"],
            promo_code=data.get("promo_code")
        )

def decode(payload: dict):
    # E5.2: if/elif zanjirisiz "type" ni qidiramiz
    event_registry = {
        "OrderPlaced": OrderPlaced,
        # "OrderCancelled": OrderCancelled # Shunga o'xshab qo'shilaveradi
    }
    event_type = payload.get("type")
    
    if event_type in event_registry:
        return event_registry[event_type].from_dict(payload)
    else:
        print(f"Skipping unknown event type: {event_type}")
        return None

def test_v1_and_v2_compatibility():
    # Eski v1 message (promo_code yo'q)
    v1_msg = {"type": "OrderPlaced", "version": 1, "order_id": 10, "total_tiyin": 500, "currency": "UZS"}
    # Yangi v2 message (promo_code va hatto nomalum field bor)
    v2_msg = {"type": "OrderPlaced", "version": 2, "order_id": 11, "total_tiyin": 700, "currency": "UZS", "promo_code": "SALE", "unknown_future_field": "123"}
    
    obj1 = decode(v1_msg)
    assert obj1.promo_code is None
    
    obj2 = decode(v2_msg)
    assert obj2.promo_code == "SALE"

def test_unknown_event():
    # Consumer o'chib qolmaydi, faqat None qaytaradi
    assert decode({"type": "UserCreated", "id": 1}) is None