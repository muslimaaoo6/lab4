# 8.1: Nima uchun TypeError? Python klasslarda metodlarni lug'at (dictionary) shaklida saqlaydi. Ikkinchi marta e'lon qilingan `search` birinchisini ustidan yozib yuborgan. Chaqirilganda u albatta `filters` argumentini ham kutadi, shuning uchun xato beradi.
# 8.2: filters={} kabi o'zgaruvchan (mutable) qiymatlarni default (standart) sifatida berish xavfli (Lab 4A eslang). Chunki bu lug'at funksiyaning barcha chaqiriqlari uchun bitta umumiy xotirani band qiladi va kutilmagan xatolar keltirib chiqaradi.
# 8.3: Men `**filters` (keyword arguments) uslubini tanladim: search('iphone', brand='Apple'). Sababi bu kodni yozayotganda ham, o'qiyotganda ham ancha toza ko'rinadi va qo'shimcha {} qavslar talab qilmaydi.
# 8.4: Asl kodni pyflakes bilan tekshirganda "redefinition of unused 'search'" degan ogohlantirishni ko'rsatadi, ya'ni metod qayta e'lon qilinganligini va birinchisi ishlatilmay qolganligini bildiradi.

class ProductSearch:
    def __init__(self, products):
        self.products = products
 
    # Bitta search metodi ham oddiy, ham filtrli qidiruvni qo'llab-quvvatlaydi
    def search(self, query, **filters):
        q = query.lower()
        result = [p for p in self.products if q in p["title"].lower()]
        
        # Qo'shimcha filtrlar berilgan bo'lsa, natijani qisqartiramiz
        for key, value in filters.items():
            result = [p for p in result if p.get(key) == value]
            
        return result

# --- Testlar ---
def test_search_without_filters():
    ps = ProductSearch([{"title": "iPhone 15", "brand": "Apple"}])
    # Filtrsiz chaqirish ishlayaptimi tekshiramiz
    assert len(ps.search("iphone")) == 1

def test_search_with_filters():
    ps = ProductSearch([
        {"title": "iPhone 15", "brand": "Apple", "storage": "128GB"},
        {"title": "iPhone 15 Pro", "brand": "Apple", "storage": "256GB"},
        {"title": "Samsung S24", "brand": "Samsung", "storage": "256GB"}
    ])
    # Filtr bilan chaqirish
    result = ps.search("iphone", storage="256GB")
    assert len(result) == 1
    assert result[0]["title"] == "iPhone 15 Pro"