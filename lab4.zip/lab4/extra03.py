from functools import partial

# E3.1: apply(total) interfeysi free_delivery uchun unchalik mos tushmadi, chunki bu metod chegirma summasini emas, bo'sh (0 yoki total) degan narsani qaytarishi kerak.
# E3.2: 0 dan pastga tushib ketmaslik qoidasi Cart ichida turishi kerak, chunki alohida DiscountRule umumiy summani bilmaydi.

# --- Function-based (Funksional uslub) ---
def ten_percent_off(total: int) -> int:
    return total * 10 // 100

def minus_fixed(amount: int, threshold: int, total: int) -> int:
    return amount if total >= threshold else 0

# partial yordamida parametrni oldindan beramiz
twenty_k_off = partial(minus_fixed, amount=20_000, threshold=200_000)

def free_delivery(total: int) -> int:
    return 15_000 if total >= 150_000 else 0

class Cart:
    def __init__(self, initial_total):
        self.total = initial_total
        self.discounts = []

    def add_discount(self, rule):
        self.discounts.append(rule)

    def calculate(self):
        final_total = self.total
        for rule in self.discounts:
            final_total -= rule(final_total)
        # Natija noldan kichik bo'lishiga yo'l qo'ymaymiz
        return max(0, final_total)

# E3.3 Review comment:
# "Oddiy matematik chegirmalar uchun funksiyalar (partial) ancha toza va qisqa. Ammo, agar qoidaga 
# nom (receipt name), vaqt (validity period) kabi qo'shimcha ma'lumotlar qo'shilsa, funksiyalarga holat (state) 
# yetishmaydi. Bunday holda klass (Class) ishlatish eng yaxshi yechimdir."

def test_functional_cart():
    c = Cart(250_000)
    c.add_discount(ten_percent_off) # 250_000 - 25,000 = 225,000
    c.add_discount(twenty_k_off)    # 225,000 - 20,000 = 205,000
    c.add_discount(free_delivery)   # 205,000 - 15,000 = 190,000
    assert c.calculate() == 190_000