class Model:
    def save(self):
        self.output.append("Model.save: INSERT/UPDATE")

class TimestampMixin:
    def save(self):
        self.output.append("TimestampMixin: set updated_at")
        super().save()

class ValidateMixin:
    def save(self):
        self.output.append("ValidateMixin: validate fields")
        if not self.is_valid:
            # 9.3: Shunchaki return qilish xavfli, chunki dasturning qolgan qismi ma'lumot saqlandi deb o'ylashi mumkin.
            # Exception ko'tarish barcha keyingi amallarni (masalan audit) darhol to'xtatadi.
            raise ValueError("Invalid invoice data")
        super().save()

class AuditMixin:
    def save(self):
        super().save()
        self.output.append("AuditMixin: write audit entry")

# 9.1 & 9.4: Invoice.__mro__ ketma-ketlikni belgilaydi. Model doim oxirida bo'lishi kerak.
class Invoice(TimestampMixin, ValidateMixin, AuditMixin, Model):
    def __init__(self, is_valid=True):
        self.output = []
        self.is_valid = is_valid

# --- Testlar ---
def test_invoice_save_order():
    inv = Invoice()
    inv.save()
    assert inv.output == [
        "TimestampMixin: set updated_at",
        "ValidateMixin: validate fields",
        "Model.save: INSERT/UPDATE",
        "AuditMixin: write audit entry"
    ]

def test_invalid_invoice_stops_save():
    inv = Invoice(is_valid=False)
    import pytest
    with pytest.raises(ValueError):
        inv.save()
    # Model saqlanmagan va Audit yozilmagan bo'lishi kerak
    assert "Model.save: INSERT/UPDATE" not in inv.output