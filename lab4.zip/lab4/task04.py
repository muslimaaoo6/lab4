# 4.1: Is-a qoidasiga ko'ra AuditLog ro'yxat(list) emas. list'ning clear(), pop(), sort(), remove() kabi metodlari xavfsizlikni buzadi.
# 4.3: Yozuvlar o'zgarmasligi uchun tuple () ishlatildi.
# 4.4: List'dagi barcha o'zgartiruvchi metodlarni xato qaytaradigan qilib chiqish (override) juda noqulay va Liskov qoidasini buzadi.

class AuditLog:
    def __init__(self):
        # Kompozitsiya: AuditLog klassi o'z ichida ro'yxatni saqlaydi, uning o'zi ro'yxat emas.
        self._log = []

    def record(self, user: str, action: str):
        # Yozuvlar o'zgarmas bo'lishi uchun (user, action) kortej(tuple) ko'rinishida saqlanadi
        self._log.append((user, action))

    def __len__(self):
        # len(log) ishlashi uchun
        return len(self._log)

    def __iter__(self):
        # for entry in log ishlashi uchun
        return iter(self._log)

    def last(self, n: int):
        return self._log[-n:]

# --- Testlar ---
def test_audit_log_append_only():
    log = AuditLog()
    log.record("admin", "approve_loan#77")
    log.record("user1", "login")
    
    assert len(log) == 2
    
    entries = [entry for entry in log]
    assert entries == [("admin", "approve_loan#77"), ("user1", "login")]
    assert log.last(1) == [("user1", "login")]

def test_audit_log_no_list_methods():
    log = AuditLog()
    log.record("admin", "approve")
    
    # clear, sort va pop metodlari yo'qligini tekshiramiz
    assert not hasattr(log, "clear")
    assert not hasattr(log, "sort")
    assert not hasattr(log, "pop")
    
    # log[0] = ... kabi o'zgartirishni amalga oshirib bo'lmasligini tekshiramiz
    import pytest
    with pytest.raises(TypeError):
        log[0] = ("hacker", "delete_logs")