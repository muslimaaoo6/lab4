class Subscription:
    VAT_PERCENT = 12

    def __init__(self, user, months):
        self.user = user
        self.months = months
        self.base_monthly = 50_000

    def net(self):
        return self.base_monthly * self.months

    def price(self):
        return self.net() * (100 + self.VAT_PERCENT) // 100

class StudentSubscription(Subscription):
    def net(self):
        return self.base_monthly * self.months // 2

class FamilySubscription(Subscription):
    def __init__(self, user, months, members):
        super().__init__(user, months)
        self.members = members

    def net(self):
        base_net = super().net()
        extra = 20_000 * (len(self.members) - 1) * self.months
        return base_net + extra

def test_standard_subscription():
    sub = Subscription("Ali", 3)
    assert sub.price() == 168_000

def test_student_subscription():
    sub = StudentSubscription("Vali", 3)
    assert sub.price() == 84_000

def test_family_subscription():
    sub = FamilySubscription("Gani", 3, ["Gani", "Wife", "Child1", "Child2"])
    assert sub.price() == 369_600