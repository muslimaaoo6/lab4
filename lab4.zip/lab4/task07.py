from dataclasses import dataclass

class CurrencyMismatchError(Exception):
    pass

# 7.1: Nima uchun @dataclass(order=True) < uchun xato? 
# Chunki order=True bo'lsa, Money(100, 'USD') > Money(1, 'UZS') taqqoslashida u avval amount'ni (100 > 1), 
# keyin valyutani ('USD' > 'UZS') taqqoslab, har xil valyutalar o'rtasida mantiqsiz True natijasini berib qo'yadi.

# 7.2: sum() qanday ishlaydi?
# sum([Money, Money]) ishlashida eng birinchi marta 0 (int) ga Money obyektini qo'shishga urinadi. 
# Buni hal qilish uchun __radd__ yozib, 0 qabul qiladigan qilish, YOKI sum() da boshlang'ich qiymatni 
# aniq ko'rsatish (sum(items, start=Money(0, 'UZS'))) mumkin. Biz __radd__ ni tanlaymiz, bu hamma joyda osonroq.

# 7.4: Pulni pulga ko'paytirish (Money * Money) yoki bo'lish mantiqsiz, shu sababli faqat int ga ko'paytirish (Money * int) ruxsat etiladi.

@dataclass(frozen=True)
class Money:
    amount: int
    currency: str

    def __add__(self, other):
        if not isinstance(other, Money):
            # 7.3: Boshqa turdagi ob'yekt bo'lsa, NotImplemented qaytariladi, shunda Python __radd__ ni qidiradi.
            return NotImplemented
        if self.currency != other.currency:
            raise CurrencyMismatchError(f"Cannot add {self.currency} and {other.currency}")
        return Money(self.amount + other.amount, self.currency)

    def __radd__(self, other):
        if other == 0:
            return self
        return self.__add__(other)

    def __mul__(self, other: int):
        if not isinstance(other, int):
            return NotImplemented
        return Money(self.amount * other, self.currency)

    def __rmul__(self, other: int):
        return self.__mul__(other)

    def __eq__(self, other):
        if not isinstance(other, Money):
            return False
        return self.amount == other.amount and self.currency == other.currency

    def __lt__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        if self.currency != other.currency:
            raise CurrencyMismatchError("Cannot compare different currencies")
        return self.amount < other.amount

# --- Testlar ---
def test_money_addition():
    assert Money(100, "UZS") + Money(200, "UZS") == Money(300, "UZS")

def test_money_addition_currency_mismatch():
    import pytest
    with pytest.raises(CurrencyMismatchError):
        _ = Money(100, "UZS") + Money(1, "USD")

def test_money_multiplication():
    assert Money(100, "UZS") * 3 == Money(300, "UZS")
    assert 3 * Money(100, "UZS") == Money(300, "UZS")

def test_money_equality():
    assert (Money(500, "UZS") == 500) is False
    assert Money(500, "UZS") == Money(500, "UZS")

def test_money_sum():
    items = [Money(100, "UZS"), Money(200, "UZS"), Money(50, "UZS")]
    assert sum(items) == Money(350, "UZS")