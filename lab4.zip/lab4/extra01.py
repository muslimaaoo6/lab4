from collections import UserDict

# E1.1: Asl kodda update(), setdefault() kabi dict usullari o'zgartirilgan __setitem__ ni aylanib o'tib ishlardi.
# E1.2 & E1.3: UserDict orqali buni xavfsiz qilib, ham o'qish ham yozishda case-insensitive qildik.

class Headers(UserDict):
    def __setitem__(self, key, value):
        super().__setitem__(key.lower(), value)

    def __getitem__(self, key):
        return super().__getitem__(key.lower())

    def __contains__(self, key):
        return super().__contains__(key.lower())

def test_headers_case_insensitive_write():
    h = Headers({"Accept": "application/json"})
    h["Content-Type"] = "text/plain"
    h.update({"Content-Type": "application/json"})
    h.setdefault("X-Request-Id", "42")
    
    assert list(h.data.keys()) == ["accept", "content-type", "x-request-id"]
    assert h["content-type"] == "application/json"

def test_headers_case_insensitive_read():
    h = Headers({"accept": "application/json"})
    assert h["ACCEPT"] == "application/json"
    assert "AcCePt" in h