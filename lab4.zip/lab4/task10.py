# Task 1 dagi klasslarni xuddi shu faylda nusxaladim (mustaqil ishlashi uchun)
from abc import ABC, abstractmethod

class PaymentMethod(ABC):
    @abstractmethod
    def fee(self, amount: int) -> int: pass

class Card(PaymentMethod):
    def fee(self, amount: int) -> int: return amount * 15 // 1000

class Click(PaymentMethod):
    def fee(self, amount: int) -> int: return amount * 10 // 1000

class Payme(PaymentMethod):
    def fee(self, amount: int) -> int: return amount * 10 // 1000

class BankTransfer(PaymentMethod):
    def fee(self, amount: int) -> int: return 5000

class UnknownPaymentMethodError(ValueError):
    pass

# 10.1 & 10.3 & 10.5: Registry pattern
PAYMENT_REGISTRY = {
    "card": Card,
    "click": Click,
    "payme": Payme,
    "banktransfer": BankTransfer
}

def create_payment_method(name: str) -> PaymentMethod:
    # Stringni tozalab (strip) va kichik harflarga (lower) o'tkazamiz
    clean_name = name.strip().lower()
    
    if clean_name not in PAYMENT_REGISTRY:
        # 10.2: Xatolik nima ekanini tushuntiradi
        supported = ", ".join(PAYMENT_REGISTRY.keys())
        raise UnknownPaymentMethodError(f"Method '{name}' is unknown. Supported: {supported}")
    
    return PAYMENT_REGISTRY[clean_name]()

# 10.4: Bu arxitektura yaxshi, chunki if/elif zanjiri kabi kod cho'zilib ketmaydi.
# Yangi metod qo'shish uchun faqat lug'atga (REGISTRY) nomini va klassni qo'shish kifoya.

def test_normalization():
    assert isinstance(create_payment_method(" Payme "), Payme)
    assert isinstance(create_payment_method("PAYME"), Payme)
    assert isinstance(create_payment_method("banktransfer"), BankTransfer)

def test_unknown_method():
    import pytest
    with pytest.raises(UnknownPaymentMethodError) as excinfo:
        create_payment_method("paypal")
    assert "Supported: card, click, payme, banktransfer" in str(excinfo.value)