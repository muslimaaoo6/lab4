import inspect

class DuplicatePaymentMethodError(Exception): pass
class MissingNameError(Exception): pass

# E2.1: Avtomatik registr
class AutoPaymentMethod:
    registry = {}

    def __init_subclass__(cls, name=None, **kwargs):
        super().__init_subclass__(**kwargs)
        
        # E2.2: Agar klass abstrakt bo'lmasa va ismi berilmasa, xato.
        if not inspect.isabstract(cls):
            if name is None:
                raise MissingNameError(f"Concrete class {cls.__name__} must have a name='...' argument")
            
            # E2.3: Ikkita bir xil nomli klass bo'lmasligi kerak
            if name in cls.registry:
                raise DuplicatePaymentMethodError(f"Method '{name}' is already registered")
            
            cls.registry[name] = cls

# E2.4: Avtomatik registrning bitta noqulayligi — agar fayl import qilinmasa (run qilinmasa), u registrda paydo bo'lmaydi.
# Task 10 dagi yondashuv bitta joyda aniq yoziladi, lekin har safar qo'lda yangilash talab qilinadi.

class ApplePay(AutoPaymentMethod, name="apple"): pass
class GooglePay(AutoPaymentMethod, name="google"): pass

def test_auto_registry():
    assert AutoPaymentMethod.registry["apple"] == ApplePay
    assert AutoPaymentMethod.registry["google"] == GooglePay

def test_duplicate_name_fails():
    import pytest
    with pytest.raises(DuplicatePaymentMethodError):
        class SecondApple(AutoPaymentMethod, name="apple"): pass

def test_missing_name_fails():
    import pytest
    with pytest.raises(MissingNameError):
        class NoName(AutoPaymentMethod): pass