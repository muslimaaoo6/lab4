# E4.1: Null Object Pattern yordamida NoLoyalty yasaymiz
class NoLoyalty:
    def discount_percent(self):
        return 0

    def points_for(self, amount):
        return 0

class LoyaltyCard:
    def __init__(self, level):
        self.level = level

    def discount_percent(self):
        return {"silver": 3, "gold": 5, "platinum": 10}[self.level]

    def points_for(self, amount):
        return amount // 10_000

class Customer:
    def __init__(self, name, loyalty=None):
        self.name = name
        # E4.2: Kim NoLoyalty yaratadi? Customer klassining o'zi __init__ ichida.
        self.loyalty = loyalty if loyalty is not None else NoLoyalty()

def checkout_summary(customer, amount):
    # E4.3: None tekshiruvi umuman keraksiz bo'lib qoldi!
    discount = amount * customer.loyalty.discount_percent() // 100
    points = customer.loyalty.points_for(amount)
    return discount, points

# E4.4: Qachon Null Object ishlatmaslik kerak?
# Foydalanuvchiga "Sizda hech narsa yo'q" deb aniq ko'rsatilishi shart bo'lgan paytlarda.
# Masalan, mijozning bank kartasi saqlanmagan bo'lsa (bank_card=None), to'lov paytida "Unda 0 puli bor karta bor" 
# deb emas, balki aniq xatolik "Karta ulanmagan" deb chiqishi shart.

def test_customer_with_card():
    c = Customer("Ali", LoyaltyCard("gold"))
    assert checkout_summary(c, 100_000) == (5_000, 10)

def test_customer_without_card():
    c = Customer("Vali")
    assert checkout_summary(c, 100_000) == (0, 0)