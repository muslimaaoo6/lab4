import io
from typing import Protocol, List, Any

# 6.1: export_report target'dan faqat bitta narsani: write(data: bytes) metodiga ega bo'lishini talab qiladi (duck typing). isinstance tekshiruvi olib tashlandi.
# 6.4: Duck typing xatolikni kod ishlagunigacha yashiradi. Lekin typing.Protocol va mypy kabi statik analizatorlar yordamida dastur ishlashidan oldin bu xatoni aniqlash mumkin.

# 6.2: Protokol yozamiz
class Writable(Protocol):
    def write(self, data: bytes) -> int:
        ...

# target parametri endi qat'iy io.IOBase emas, balki Writable protokoli turiga ega
def export_report(rows: List[List[Any]], target: Writable):
    for r in rows:
        target.write((",".join(map(str, r)) + "\n").encode())

class S3Upload:
    def __init__(self, bucket: str, key: str):
        self.bucket = bucket
        self.key = key
        self.parts: List[bytes] = []

    def write(self, data: bytes) -> int:
        self.parts.append(data)
        return len(data)

class FakeTarget:
    def __init__(self):
        self.written_data = b""
        
    def write(self, data: bytes) -> int:
        self.written_data += data
        return len(data)

# --- Testlar (6.3) ---
def test_export_report_bytesio():
    target = io.BytesIO()
    export_report([["a", "b"], ["1", "2"]], target)
    assert target.getvalue() == b"a,b\n1,2\n"

def test_export_report_s3upload():
    target = S3Upload("my-bucket", "report.csv")
    export_report([["x", "y"]], target)
    assert target.parts == [b"x,y\n"]

def test_export_report_fake_target():
    target = FakeTarget()
    export_report([["hello", "world"]], target)
    assert target.written_data == b"hello,world\n"