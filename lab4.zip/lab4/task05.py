import datetime

# 5.1: "O'qituvchi - bu xodim" qoidasi xodimning butun hayoti davomida amal qilmaydi, 
# chunki xodimning lavozimi o'zgarishi mumkin. Lavozim o'zgarganda faqat "Role" (rol) o'zgaradi, shaxs emas.

class Role:
    def monthly_pay(self):
        pass

class LecturerRole(Role):
    def __init__(self, hours):
        self.hours = hours

    def monthly_pay(self):
        return self.hours * 120_000

class HeadRole(Role):
    def __init__(self, salary):
        self.salary = salary

    def monthly_pay(self):
        return self.salary + 3_000_000

class Employee:
    def __init__(self, emp_id, name, initial_role):
        self.emp_id = emp_id
        self.name = name
        # 5.4: Xodim va uning lavozimlar tarixi o'rtasida "Birga-Ko'p" (One-to-Many) munosabati mavjud.
        self.role_history = [(initial_role, datetime.date.today())]

    @property
    def current_role(self):
        # Eng oxirgi qo'shilgan lavozimni qaytaradi
        return self.role_history[-1][0]

    def monthly_pay(self):
        # 5.2: if/else ishlatmasdan polimorfizm orqali to'g'ridan-to'g'ri hisoblaymiz
        return self.current_role.monthly_pay()

    def change_role(self, new_role):
        # 5.3: Obyekt (Employee) va uning ID si o'zgarmaydi, faqat tarixga yangi rol qo'shiladi
        self.role_history.append((new_role, datetime.date.today()))

# --- Testlar ---
def test_employee_promotion():
    # Boshida o'qituvchi bo'lib ishga kirdi (10 soat)
    emp = Employee(1, "Ali", LecturerRole(10))
    assert emp.monthly_pay() == 1_200_000

    # Kafedra mudiri lavozimiga ko'tarildi
    emp.change_role(HeadRole(14_000_000))
    
    # Oylik endi yangi lavozim bo'yicha hisoblanadi (14 mln + 3 mln bonus)
    assert emp.monthly_pay() == 17_000_000
    
    # Xodimning ID'si va obyekti o'zgargani yo'q, tarixda esa 2 ta lavozimi bor
    assert emp.emp_id == 1
    assert len(emp.role_history) == 2